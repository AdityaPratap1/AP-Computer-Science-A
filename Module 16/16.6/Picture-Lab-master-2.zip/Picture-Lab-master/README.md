Picture-Lab
===========

Picture Lab for IB/AP Computer Science.

<h3>About the project</h3>
This project is the last lab for computer science, first semester.

<h3>Usage</h3>
This project works best on [BlueJ](http://www.bluej.org/). Simply load the classes folder onto BlueJ, and it should be ready to compile.

<h3>Contributors</h3>
 - Jackson Chen
 - Will Kaufman
